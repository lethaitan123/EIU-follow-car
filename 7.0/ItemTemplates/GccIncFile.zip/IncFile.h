/*
 * $safeitemname$.h
 *
 * Created: $date$
 *  Author: $user$
 */ 


#ifndef $HeaderFileName$_H_
#define $HeaderFileName$_H_





#endif /* $HeaderFileName$_H_ */