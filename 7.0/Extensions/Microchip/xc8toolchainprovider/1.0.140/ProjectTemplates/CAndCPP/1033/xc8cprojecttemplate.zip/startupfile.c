/*
 * $safeitemname$.c
 *
 * Created: $time$
 *  Author: $username$
 */ 

#include <xc.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}