/*
 * $safeitemname$.c
 *
 * Created: $time$
 *  Author: $username$
 */ 

#include <xc.h>

 /* Replace with your library code */
int myfunc(void)
{
	return 0;
}